JOYA RECHARGE APK PROJECT

Is project me user ka existing V3 HTML app/src/main/assets/index.html me bina code rewrite kiye rakha gaya hai.

BUILD:
1. Android Studio me is folder ko Open karein.
2. Gradle sync complete hone dein.
3. Build > Generate App Bundles or APKs > Generate APKs.
4. APK app/build/outputs/apk/release/ ya debug/ me milega.

IMPORTANT:
- Yeh source project hai; is environment me Android SDK/Gradle available na hone ki wajah se yahan actual APK compile nahi kiya gaya.
- UPI intent ko Android WebView ke through external UPI apps tak hand-off karne ke liye MainActivity me handling add hai.
- Existing HTML ko assets/index.html me copy kiya gaya hai.
